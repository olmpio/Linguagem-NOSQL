package com.example.demo_integracao_mongodb.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "estudante")
public class Estudante {
    @Id
    private String id;

    @Field("nome")
    private String name;

    @Field("idade")
    private int idade;

    @Field("email_principal")
    private String email;

    public Estudante() {
    }

    public Estudante(String id, String name, int idade, String email) {
        this.id = id;
        this.name = name;
        this.idade = idade;
        this.email = email;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Corrigido para retornar String e corresponder ao campo 'name'
    public String getNome() {
        return name;
    }

    public void setNome(String name) {
        this.name = name;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}